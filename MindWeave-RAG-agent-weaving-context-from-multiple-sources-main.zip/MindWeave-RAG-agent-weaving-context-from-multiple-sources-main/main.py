def main():
    print("Hello from agent-rag01!")


if __name__ == "__main__":
    main()
